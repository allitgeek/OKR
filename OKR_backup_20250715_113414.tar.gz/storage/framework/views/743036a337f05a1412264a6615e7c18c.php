<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <div>
                <h2 class="text-2xl font-bold text-gray-800 leading-tight">
                    <?php echo e($objective->title); ?>

                </h2>
                <p class="mt-1 text-sm text-gray-600">Created <?php echo e($objective->created_at->diffForHumans()); ?></p>
            </div>
            <div class="flex items-center space-x-3">
                <a href="<?php echo e(route('objectives.edit', $objective)); ?>" 
                   class="inline-flex items-center px-4 py-2 bg-white border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-150">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                    </svg>
                    <?php echo e(__('Edit Objective')); ?>

                </a>
                <form action="<?php echo e(route('objectives.destroy', $objective)); ?>" method="POST" class="inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" 
                            class="inline-flex items-center px-4 py-2 bg-white border border-red-300 rounded-lg text-sm font-medium text-red-700 hover:bg-red-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors duration-150"
                            onclick="return confirm('Are you sure you want to delete this objective?')">
                        <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                        <?php echo e(__('Delete')); ?>

                    </button>
                </form>
            </div>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <!-- Objective Details -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-6">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <h3 class="text-lg font-medium text-gray-900 mb-2"><?php echo e(__('Description')); ?></h3>
                            <p class="text-gray-600"><?php echo e($objective->description ?: 'No description provided.'); ?></p>
                        </div>
                        <div>
                            <h3 class="text-lg font-medium text-gray-900 mb-2"><?php echo e(__('Details')); ?></h3>
                            <dl class="space-y-2">
                                <div class="flex justify-between">
                                    <dt class="text-gray-600">Time Period</dt>
                                    <dd class="font-medium text-gray-900"><?php echo e(ucfirst($objective->time_period)); ?></dd>
                                </div>
                                <div class="flex justify-between">
                                    <dt class="text-gray-600">Start Date</dt>
                                    <dd class="font-medium text-gray-900"><?php echo e($objective->start_date->format('M d, Y')); ?></dd>
                                </div>
                                <div class="flex justify-between">
                                    <dt class="text-gray-600">End Date</dt>
                                    <dd class="font-medium <?php echo e($objective->end_date->isPast() ? 'text-red-600' : 'text-gray-900'); ?>">
                                        <?php echo e($objective->end_date->format('M d, Y')); ?>

                                    </dd>
                                </div>
                            </dl>
                        </div>
                    </div>

                    <!-- Overall Progress -->
                    <div class="mt-8">
                        <div class="flex items-center justify-between mb-2">
                            <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Overall Progress')); ?></h3>
                            <span class="text-lg font-semibold <?php echo e($objective->progress >= 100 ? 'text-green-600' : 'text-blue-600'); ?>">
                                <?php echo e($objective->progress); ?>%
                            </span>
                        </div>
                        <div class="w-full bg-gray-200 rounded-full h-3">
                            <div class="h-3 rounded-full transition-all duration-300 ease-in-out <?php echo e($objective->progress >= 100 ? 'bg-green-500' : 'bg-blue-500'); ?>"
                                 style="width: <?php echo e($objective->progress); ?>%">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Key Results -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg mb-6">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-gray-900">Key Results</h3>
                        <a href="<?php echo e(route('key-results.create', ['objective_id' => $objective->id])); ?>"
                           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors duration-150 ease-in-out">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                            </svg>
                            Add Key Result
                        </a>
                    </div>

                    <div class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $objective->keyResults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyResult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors duration-150">
                                <div class="flex items-center justify-between mb-3">
                                    <h4 class="text-lg font-medium text-gray-900"><?php echo e($keyResult->title); ?></h4>
                                    <div class="flex items-center space-x-2">
                                        <button type="button" 
                                            x-data
                                            @click="$dispatch('open-modal', 'update-progress-<?php echo e($keyResult->id); ?>')" 
                                            class="text-gray-600 hover:text-blue-600 transition-colors duration-150 p-1 rounded-full hover:bg-blue-100" 
                                            title="Update Progress">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                                            </svg>
                                        </button>
                                        <button type="button" 
                                            onclick="markComplete('<?php echo e($keyResult->id); ?>')" 
                                            class="text-gray-600 hover:text-green-600 transition-colors duration-150 p-1 rounded-full hover:bg-green-100" 
                                            title="Mark Complete">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                            </svg>
                                        </button>
                                        <a href="<?php echo e(route('key-results.edit', $keyResult)); ?>" 
                                           class="text-gray-600 hover:text-blue-600 transition-colors duration-150 p-1 rounded-full hover:bg-blue-100" 
                                           title="Edit">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                            </svg>
                                        </a>
                                        <form action="<?php echo e(route('key-results.destroy', $keyResult)); ?>" method="POST" class="inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" 
                                                class="text-gray-600 hover:text-red-600 transition-colors duration-150 p-1 rounded-full hover:bg-red-100" 
                                                title="Delete" 
                                                onclick="return confirm('Are you sure you want to delete this key result?')">
                                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                                                </svg>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                                
                                <div class="space-y-3">
                                    <div class="flex items-center">
                                        <div class="flex-grow">
                                            <div class="h-2 bg-gray-200 rounded-full overflow-hidden">
                                                <div class="h-2 <?php echo e($keyResult->progress >= 100 ? 'bg-green-500' : 'bg-blue-500'); ?> rounded-full transition-all duration-300 ease-in-out" 
                                                     style="width: <?php echo e(($keyResult->current_value / $keyResult->target_value) * 100); ?>%">
                                                </div>
                                            </div>
                                        </div>
                                        <span class="ml-3 text-sm font-medium <?php echo e($keyResult->progress >= 100 ? 'text-green-600' : 'text-blue-600'); ?>">
                                            <?php echo e(number_format(($keyResult->current_value / $keyResult->target_value) * 100, 1)); ?>%
                                        </span>
                                    </div>
                                    <div class="flex justify-between items-center text-sm">
                                        <div class="text-gray-600">
                                            Current: <span class="font-medium text-gray-900"><?php echo e($keyResult->current_value); ?></span>
                                            / Target: <span class="font-medium text-gray-900"><?php echo e($keyResult->target_value); ?></span>
                                        </div>
                                        <div class="text-gray-600">
                                            Owner: <span class="font-medium text-gray-900"><?php echo e($keyResult->owner->name); ?></span>
                                        </div>
                                    </div>
                                    <div class="text-sm text-gray-500">
                                        Last Updated: <?php echo e($keyResult->updated_at->diffForHumans()); ?>

                                    </div>
                                </div>
                            </div>

                            <!-- Progress Update Modal -->
                            <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['name' => 'update-progress-'.e($keyResult->id).'','show' => false,'maxWidth' => 'md']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'update-progress-'.e($keyResult->id).'','show' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false),'maxWidth' => 'md']); ?>
                                <form method="POST" action="<?php echo e(route('key-results.update-progress', $keyResult)); ?>" class="p-6">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    
                                    <h2 class="text-lg font-medium text-gray-900 mb-4">
                                        Update Progress for "<?php echo e($keyResult->title); ?>"
                                    </h2>

                                    <div class="mb-6 p-4 bg-gray-50 rounded-lg">
                                        <div class="flex justify-between items-center mb-2">
                                            <span class="text-sm text-gray-600">Current Progress</span>
                                            <span class="text-sm font-medium <?php echo e($keyResult->progress >= 100 ? 'text-green-600' : 'text-blue-600'); ?>">
                                                <?php echo e(number_format(($keyResult->current_value / $keyResult->target_value) * 100, 1)); ?>%
                                            </span>
                                        </div>
                                        <div class="flex justify-between items-center">
                                            <span class="text-sm text-gray-600">Target Value</span>
                                            <span class="text-sm font-medium text-gray-900"><?php echo e($keyResult->target_value); ?></span>
                                        </div>
                                    </div>

                                    <div>
                                        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => 'current_value_'.e($keyResult->id).'','value' => __('Current Value')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'current_value_'.e($keyResult->id).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(__('Current Value'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
                                        <?php if (isset($component)) { $__componentOriginal18c21970322f9e5c938bc954620c12bb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal18c21970322f9e5c938bc954620c12bb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.text-input','data' => ['id' => 'current_value_'.e($keyResult->id).'','name' => 'current_value','type' => 'number','class' => 'mt-1 block w-full','value' => old('current_value', $keyResult->current_value),'required' => true,'min' => '0','max' => ''.e($keyResult->target_value).'','step' => '0.01','autofocus' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('text-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'current_value_'.e($keyResult->id).'','name' => 'current_value','type' => 'number','class' => 'mt-1 block w-full','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('current_value', $keyResult->current_value)),'required' => true,'min' => '0','max' => ''.e($keyResult->target_value).'','step' => '0.01','autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $attributes = $__attributesOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__attributesOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal18c21970322f9e5c938bc954620c12bb)): ?>
<?php $component = $__componentOriginal18c21970322f9e5c938bc954620c12bb; ?>
<?php unset($__componentOriginal18c21970322f9e5c938bc954620c12bb); ?>
<?php endif; ?>
                                        <div class="mt-2 flex space-x-2">
                                            <button type="button" 
                                                class="quick-value-btn px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors duration-150" 
                                                data-target="<?php echo e($keyResult->target_value); ?>" 
                                                data-value="25">25%</button>
                                            <button type="button" 
                                                class="quick-value-btn px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors duration-150" 
                                                data-target="<?php echo e($keyResult->target_value); ?>" 
                                                data-value="50">50%</button>
                                            <button type="button" 
                                                class="quick-value-btn px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors duration-150" 
                                                data-target="<?php echo e($keyResult->target_value); ?>" 
                                                data-value="75">75%</button>
                                            <button type="button" 
                                                class="quick-value-btn px-3 py-1 text-sm bg-gray-100 hover:bg-gray-200 rounded-md transition-colors duration-150" 
                                                data-target="<?php echo e($keyResult->target_value); ?>" 
                                                data-value="100">100%</button>
                                        </div>
                                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['class' => 'mt-2','messages' => $errors->get('current_value')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-2','messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('current_value'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                                    </div>

                                    <div class="mt-6 flex justify-end space-x-3">
                                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['type' => 'button','@click' => '$dispatch(\'close-modal\', \'update-progress-'.e($keyResult->id).'\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'button','@click' => '$dispatch(\'close-modal\', \'update-progress-'.e($keyResult->id).'\')']); ?>
                                            <?php echo e(__('Cancel')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>

                                        <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>
                                            <?php echo e(__('Update Progress')); ?>

                                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                                    </div>
                                </form>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-8">
                                <p class="text-gray-500 mb-4">No key results defined yet</p>
                                <a href="<?php echo e(route('key-results.create', ['objective_id' => $objective->id])); ?>"
                                   class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors duration-150 ease-in-out">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                    </svg>
                                    Add Your First Key Result
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Tasks Section -->
            <div class="bg-white overflow-hidden shadow-sm rounded-lg">
                <div class="p-6">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-lg font-medium text-gray-900"><?php echo e(__('Tasks')); ?></h3>
                        <a href="<?php echo e(route('tasks.create', ['objective_id' => $objective->id])); ?>"
                           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors duration-150 ease-in-out">
                            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                            </svg>
                            <?php echo e(__('Add Task')); ?>

                        </a>
                    </div>

                    <div class="space-y-4">
                        <?php $__empty_1 = true; $__currentLoopData = $objective->tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors duration-150">
                                <div class="flex justify-between items-start">
                                    <div>
                                        <h4 class="font-medium text-gray-900"><?php echo e($task->title); ?></h4>
                                        <p class="text-gray-600 mt-1"><?php echo e($task->description); ?></p>
                                        <div class="mt-2 flex items-center space-x-2">
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium <?php echo e($task->status === 'completed' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                                                <?php echo e(ucfirst($task->status)); ?>

                                            </span>
                                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                                Due: <?php echo e($task->due_date?->format('M d, Y') ?? 'No due date'); ?>

                                            </span>
                                        </div>
                                    </div>
                                    <div class="flex items-center space-x-2">
                                        <?php if($task->status !== 'completed'): ?>
                                            <form action="<?php echo e(route('tasks.complete', $task)); ?>" method="POST" class="inline">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" 
                                                    class="text-gray-600 hover:text-green-600 transition-colors duration-150 p-1 rounded-full hover:bg-green-100"
                                                    title="Complete Task">
                                                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
                                                    </svg>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <a href="<?php echo e(route('tasks.edit', $task)); ?>"
                                           class="text-gray-600 hover:text-blue-600 transition-colors duration-150 p-1 rounded-full hover:bg-blue-100"
                                           title="Edit Task">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"></path>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center py-8">
                                <p class="text-gray-500 mb-4"><?php echo e(__('No tasks created yet.')); ?></p>
                                <a href="<?php echo e(route('tasks.create', ['objective_id' => $objective->id])); ?>"
                                   class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-lg transition-colors duration-150 ease-in-out">
                                    <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                                    </svg>
                                    Create Your First Task
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Function to mark key result as complete
            window.markComplete = function(keyResultId) {
                if (confirm('Are you sure you want to mark this key result as complete?')) {
                    const form = document.createElement('form');
                    form.method = 'POST';
                    form.action = `/key-results/${keyResultId}/complete`;
                    
                    const csrfToken = document.querySelector('meta[name="csrf-token"]').content;
                    const csrfInput = document.createElement('input');
                    csrfInput.type = 'hidden';
                    csrfInput.name = '_token';
                    csrfInput.value = csrfToken;
                    
                    const methodInput = document.createElement('input');
                    methodInput.type = 'hidden';
                    methodInput.name = '_method';
                    methodInput.value = 'PATCH';
                    
                    form.appendChild(csrfInput);
                    form.appendChild(methodInput);
                    document.body.appendChild(form);
                    form.submit();
                }
            };

            // Handle quick value buttons
            document.querySelectorAll('.quick-value-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const percentage = parseInt(this.dataset.value);
                    const targetValue = parseFloat(this.dataset.target) || 100;
                    const currentValueInput = this.closest('form').querySelector('input[name="current_value"]');
                    const newValue = (percentage / 100) * targetValue;
                    currentValueInput.value = newValue.toFixed(2);
                });
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?> <?php /**PATH C:\Users\Faisal\OneDrive\Desktop\Projects\OKR\resources\views/objectives/show.blade.php ENDPATH**/ ?>