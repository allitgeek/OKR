# OKR (Objectives and Key Results) Management System

A comprehensive web application built with Laravel for managing Objectives and Key Results (OKRs) within an organization. This system helps teams track their goals, measure progress, and maintain accountability.

## Features

### User Management
- Role-based access control (Admin, Manager, User)
- User authentication and authorization
- Profile management
- Super admin capabilities
- Modern icon-based interface for user actions

### Objectives Management
- Create and manage organizational objectives
- Track objective progress
- Assign objectives to teams/individuals
- Set deadlines and priorities

### Key Results
- Link key results to objectives
- Measure progress quantitatively
- Update status and completion percentage
- Add comments and attachments

### Task Management
- Break down key results into actionable tasks
- Task assignment and acceptance
- Due date tracking
- Task escalation for overdue items

### Team Collaboration
- Team creation and management
- Comment system for discussions
- File attachments support
- Activity logging

### UI/UX Features
- Responsive design for mobile and desktop
- Navy blue theme with modern aesthetics
- Intuitive navigation
- Modal-based forms for better user experience
- Icon-based actions for cleaner interface

## Technical Stack

- **Framework**: Laravel 10.x
- **Frontend**: 
  - Blade templates
  - Tailwind CSS
  - Alpine.js
- **Database**: SQLite
- **Authentication**: Laravel Breeze
- **Authorization**: Custom roles and permissions system

## Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   composer install
   npm install
   ```
3. Copy `.env.example` to `.env` and configure your environment
4. Generate application key:
   ```bash
   php artisan key:generate
   ```
5. Run migrations and seeders:
   ```bash
   php artisan migrate --seed
   ```
6. Build assets:
   ```bash
   npm run dev
   ```
7. Start the development server:
   ```bash
   php artisan serve
   ```

## Usage

1. Register a new account or use the default admin account:
   - Email: admin@example.com
   - Password: password

2. Create objectives and assign key results
3. Break down key results into tasks
4. Track progress and update status
5. Manage users and their roles

## Security

- CSRF protection enabled
- Form validation
- Secure password hashing
- Role-based access control
- Session management
- XSS protection

## Contributing

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Create a new Pull Request

## License

This project is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).
